export const colors = {
           mainColor:"#ffffff",
           black:"#000000",
           white:"white",
           buttonColor:"#FF4F5A",
           descriptionColor:"#232E35",
           signUpBtn:"#0B394E",
           greyText:"#AAAAAA",
           notes:"#7A93A7",
           time:"#8A8A8A"

}