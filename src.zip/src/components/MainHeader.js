import { Image, StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import React from 'react'
import { colors } from './Colors'
import StatusBarComponent from './StatusBarComponent'
import { scale } from 'react-native-size-matters'
import { windowWidth } from './CommonStyles'
import { images,imageBaseUrl } from './Images'
import { useNavigation } from '@react-navigation/native'
import { useSelector } from 'react-redux'
//import Orientation from 'react-native-orientation-locker'

const MainHeader = ({ backIcon, menu, customStyle }) => {
    const userDetails = useSelector(state => state.auth.user)
    const navigation = useNavigation()
    return (
        <View style={styles.HeaderBox(customStyle)}>
            <StatusBarComponent backgroundColor={colors.signUpBtn} color={colors.white} />
            <View style={styles.contentBox}>
                <View style={styles.userDetails}>
                    <Image
                        source={userDetails.image ? { uri: `${imageBaseUrl}` + userDetails.image } : images.dp}
                        style={styles.profilePic}
                    />
                    <Text style={styles.heyText}>Hey!</Text>
                    <Text numberOfLines={1} style={styles.userName}>, {userDetails.name}</Text>
                </View>
                {backIcon &&
                    <TouchableOpacity onPress={() => {
                        navigation.goBack()
                        // Orientation.lockToPortrait()
                    }} >

                        <Image
                            source={images.leftArrow}
                            style={styles.menu}
                        />
                    </TouchableOpacity>
                }
                {menu &&
                    <TouchableOpacity onPress={() => navigation.openDrawer()} >

                        <Image
                            source={images.menu}
                            style={styles.drawerMenu}
                        />
                    </TouchableOpacity>
                }
            </View>
        </View>
    )
}

export default MainHeader

const styles = StyleSheet.create({
    HeaderBox: (customStyle) => {
        return {
            height: scale(80),
            backgroundColor: colors.signUpBtn,
            width: windowWidth,
            borderBottomLeftRadius: scale(30),
            borderBottomRightRadius: scale(30),
            justifyContent: "center",
            ...customStyle
        }
    },
    contentBox: {
        height: "50%",
        width: "90%",
        alignSelf: "center",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between"

    },
    userDetails: {
        height: "100%",
        width: windowWidth / 2,
        alignItems: "center",
        flexDirection: "row"
    },
    profilePic: {
        height: 35,
        width: 35,
        borderRadius: 20,
        overflow: "hidden"
    },
    heyText:
    {
        fontSize: 20,
        color: colors.buttonColor,
        fontWeight: "600",
        left: 6
    },
    userName: {
        fontSize: 20,
        color: colors.white,
        left: 6
    },
    menu: {
        height: 18,
        width: 15,
        borderRadius: 20,
        overflow: "hidden",
        position: "absolute", right: 5,
        top:-3
    },
    drawerMenu: {
        height: 18,
        width: 25,
        // borderRadius: 20,
        // overflow: "hidden",
        position: "absolute", right: 5,
    },
})