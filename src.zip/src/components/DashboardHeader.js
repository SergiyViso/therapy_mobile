import { Image, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native'
import React, { useState } from 'react'
import { images,imageBaseUrl } from './Images'
import { colors } from './Colors'
import { scale } from 'react-native-size-matters'
import { windowHeight, windowWidth } from './CommonStyles'
import { useNavigation } from '@react-navigation/native'
import { useSelector } from 'react-redux'

const DashboardHeader = (props) => {
    const userDetails = useSelector(state=>state.auth.user)
    const [ search ,setSearch ]= useState("")
    const navigation = useNavigation()
    return (
        <View style={styles.headerBox}>
            <View style={styles.topBox}>
                <Image
                    source={userDetails.image ? { uri: `${imageBaseUrl}` + userDetails.image } : images.dp}
                    style={styles.profilePic}
                    resizeMode="contain"
                />
                <Text style={styles.heyText}>Hey!</Text>
                <Text numberOfLines={1} style={styles.userName}>, {userDetails.name}</Text>
                <TouchableOpacity onPress={()=>navigation.openDrawer()} style={styles.menu}>
                <Image
                    source={images.menu}
                    style={styles.menuImage}
                    resizeMode="contain"
                    />
                    </TouchableOpacity>
            </View>
            <View style={styles.inputBox}>
                <TextInput 
                value={search}
                onChangeText={(t)=>setSearch(t)}
                placeholder='Search'
                style={styles.input}
                />
                <Image
                    source={images.search}
                    style={styles.menu}
                    resizeMode="contain"
                />
            </View>
        </View>
    )
}

export default DashboardHeader

const styles = StyleSheet.create({
    headerBox: {
        height: windowHeight / 5,
        width: windowWidth,
        borderBottomLeftRadius: 20,
        borderBottomRightRadius: 20,
        backgroundColor: colors.signUpBtn
    },
    topBox: {
        height: "25%",
        width: "90%",
        alignSelf: "center",
        top: 10,
        flexDirection: "row",
        alignItems: "center"
    },
    profilePic: {
        height: 35,
        width: 35,
        borderRadius: 20,
        overflow: "hidden"
    },
    menu: {
        height: scale(22),
        width: scale(22),
        position: "absolute",
        right: 10
    },
    menuImage: {
        height: 28,
        width: 28,
        
    },
    heyText:
        { fontSize: 20, color: colors.buttonColor, fontWeight: "600", left: 6 },
    userName: { fontSize: 20, color: colors.white, left: 6 },
    inputBox: {
        height: "25%",
        backgroundColor: colors.white,
        marginTop: scale(15),
        width: '85%',
        alignSelf: "center",
        borderRadius: 8,
        flexDirection:"row",
        alignItems:"center"
    },
    input:{
        height:"100%",
        width:"85%",
        paddingLeft:15
    }

})