import { Image, StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import React from 'react'
import { images } from './Images'
import { colors } from './Colors'
import { moderateScale, scale } from 'react-native-size-matters'
import { fontScalingFactor, windowHeight, windowWidth } from './CommonStyles'
import { useNavigation } from '@react-navigation/native'

const DashBoardBoxes = () => {
    return (
            <Text>DashBoardBoxes</Text>
    )
}

export const CalenderBox = () => {
    const navigation = useNavigation()
    return (
        <TouchableOpacity activeOpacity={1} onPress={()=>navigation.navigate("Calendar") } style={styles.commonBox}>
            <Image
                source={images.calenderImage}
                style={{ height: "95%", width: "65%" }}
            />
            <View style={{ paddingLeft: scale(15),height:"100%",width:"35%",justifyContent:"center" }}>
                <Text style={[styles.boxTitle, { color: colors.signUpBtn }]}>Calendar</Text>
                <View style={styles.clickHereBox}>
                    <Text style={[styles.clickHere, { color: colors.signUpBtn, marginLeft: 3 }]}>Click here</Text>
                    <Image
                        source={images.redRightArrow}
                        style={{ height: 12, width: 12, left: 4 }}
                    />
                </View>
            </View>
        </TouchableOpacity>
    )
}
export const ChallengesBox = () => {
    const navigation = useNavigation()
    return (
        <TouchableOpacity activeOpacity={1} style={styles.middleBox} >

            <View style={{ paddingLeft: scale(15),top:scale(-30) }}>
                <Text style={[styles.boxTitle, { color: colors.signUpBtn, zIndex: 3, }]}>Challenges</Text>
                <View style={styles.clickHereBox}>
                    <Text style={[styles.clickHere, { color: colors.signUpBtn, marginLeft: 3 }]}>Click here</Text>
                    <Image
                        source={images.redRightArrow}
                        style={{ height: 12, width: 12, left: 4 }}
                    />
                </View>
            </View>
            <Image
                source={images.challenges}
                style={{ height: "90%", width: "35%", position: "absolute", right: scale(15) }}
            />
        </TouchableOpacity>
    )
}

export const GoalBox = () => {
    const navigation = useNavigation()
    return (
        <TouchableOpacity activeOpacity={1} style={styles.newGoalBox} onPress={()=>navigation.navigate("Goals")}>
           
            <Image
                source={images.goalsScreenImage}
                style={{ height: "72%", width: "40%",alignSelf:"center",marginHorizontal:"25%",maxWidth:scale(120)}}
            />
            
         
            <View style={{ marginLeft:"28%", position: "absolute",zIndex:33,bottom:scale(0),alignItems:"center",height:scale(40) }}>
                <Text style={[styles.boxTitle, { color: colors.signUpBtn,alignSelf:"center" }]}>Goals</Text>
                <View style={styles.clickHereBox}>
                    <Text style={[styles.clickHere, { color: colors.signUpBtn, marginBottom:2 }]}>Click here</Text>
                    <Image
                        source={images.redRightArrow}
                        style={{ height: 12, width: 12, left: 4 }}
                    />
                </View>
            </View>
        </TouchableOpacity>
    )
}
export const MonitorProgessBox = () => {
    const navigation = useNavigation()
    return (
        <TouchableOpacity style={styles.commonBox}
         onPress={()=>navigation.navigate("SymptomsGraph")}
        >
        <Image
            source={images.monitorProgress}
            style={{ height: "100%", width: "100%" }}
        />
        <View style={styles.upeerTextView}>
            <Text style={styles.monitorBoxTitle}>Monitor Your Progress</Text>
            <View style={styles.clickHereBox}>
                <Text style={[styles.clickHere, { color: colors.signUpBtn, marginLeft: 3 }]}>Click here</Text>
                <Image
                    source={images.redRightArrow}
                    style={{ height: 12, width: 12, left: 4 }}
                />
            </View>
        </View>
    </TouchableOpacity>
    )
}

export default DashBoardBoxes

const styles = StyleSheet.create({
    boxTitle: {
        fontSize: moderateScale(18)/fontScalingFactor,
        color: colors.white,
        fontWeight: "600"
    },
    clickHere: {
        fontSize: moderateScale(10)/fontScalingFactor,
        color: colors.white,
        fontWeight: "400"
    },
    commonBox: {
        flexDirection: "row",
        height: windowHeight * 0.17,
        width: windowWidth - scale(60),
        alignSelf: "center",
        marginVertical: scale(10),
        borderRadius: moderateScale(10)/fontScalingFactor,
        alignItems: "center",
        shadowColor: colors.black,
        shadowOffset: { height: 1, width: 1 },
        shadowOpacity: 1,
        shadowRadius: 1,
        elevation: 1,
         overflow: "hidden"
    },
    GoalBox: {
        flexDirection: "row",
        height: windowHeight * 0.17,
        width: windowWidth / 3,
        alignSelf: "center",
        marginVertical: scale(10),
        borderRadius: moderateScale(10)/fontScalingFactor,
        alignItems: "center",
        shadowColor: colors.black,
        shadowOffset: { height: 1, width: 1 },
        shadowOpacity: 5,
        shadowRadius: 2,
        elevation: 1
        , overflow: "hidden"
    },
    newGoalBox: {
        flexDirection: "row",
        height: windowHeight * 0.17,
        // width: windowWidth / 3,
        width: windowWidth - scale(60),
        alignSelf: "center",
        // marginVertical: scale(10),
        borderRadius: moderateScale(10)/fontScalingFactor,
        alignItems: "center",
        shadowColor: colors.black,
        shadowOffset: { height: 1, width: 1 },
        shadowOpacity: 1,
        shadowRadius: 1,
        elevation: 1,
         overflow: "hidden",
    },
    middleBox: {
        flexDirection: "row",
        height: windowHeight * 0.17,
        width: windowWidth / 2.2,
        alignSelf: "center",
        marginVertical: scale(10),
        borderRadius: moderateScale(10)/fontScalingFactor,
        alignItems: "center",
        shadowColor: colors.black,
        shadowOffset: { height: 1, width: 1 },
        shadowOpacity: 1,
        shadowRadius: 1,
        elevation: 1
        , overflow: "hidden"
    },
    clickHereBox: {
        flexDirection: "row", alignItems: "center",
    },
    upeerTextView: {
        position: "absolute", top: scale(8),
        width: "90%",
        height: scale(30),
        alignItems: "center",
        justifyContent: 'space-between',
        left: "5%",
        flexDirection: "row"
    },
    monitorBoxTitle: {
        fontSize: moderateScale(15)/fontScalingFactor,
        fontWeight: "500",
        color: colors.signUpBtn,
    }
})