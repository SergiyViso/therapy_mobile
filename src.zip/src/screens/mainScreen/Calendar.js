import { useNavigation } from '@react-navigation/native';
import moment from 'moment';
import React, { Component, useEffect, useState } from 'react';
import { Modal, ScrollView, TextInput } from 'react-native';
import { StyleSheet, Text, View, TouchableOpacity, SafeAreaView, Image } from 'react-native';
import { Agenda } from 'react-native-calendars';
import { moderateScale, scale } from 'react-native-size-matters';
import { useDispatch, useSelector } from 'react-redux';
import { deleteCalendarEvent, eventCellCalender, getCalendarData, updateCalendarEvent } from '../../../redux/actions/mainAction';
import { colors } from '../../components/Colors';
import CommonButtons from '../../components/CommonButtons';
import { commonStyles, errorToast, fontScalingFactor, successToast, windowHeight, windowWidth } from '../../components/CommonStyles'
import { images } from '../../components/Images';
import LoadingComponent from '../../components/LoadingComponent';
import MainHeader from '../../components/MainHeader'
import DatePicker from 'react-native-date-picker'
import { Button } from 'react-native';
import PushNotification from 'react-native-push-notification';
PushNotification.configure({
  // (optional) Called when Token is generated (iOS and Android)
  onRegister: function (token) {
    // console.log('TOKEN:', token);
  },
  onNotification: function (notification) {
    console.log('NOTIFICATION:', notification);
  },
  popInitialNotification: true,
  requestPermissions: true,
  // IOS ONLY (optional): default: all - Permissions to register.
  permissions: {
    alert: true,
    badge: false,
    sound: false,
  },
});
const Calendar = () => {
  const token = useSelector(state => state.auth.accessToken)
  const CalendarDataList = useSelector(state => state.main.calendarData)
  const [modal2, setModal2] = useState(false)
  const [loader, setLoader] = useState(false)
  const [eventTitle, setEventTitle] = useState('')
  const [dateString, setDateString] = useState('')
  const [btnName, setBtnName] = useState(false)
  const [eventDescription, setEventDescription] = useState('')
  const [hours, setHours] = useState('')
  const [minutes, setMinutes] = useState('')
  const [creatingType, setCreatingType] = useState('')
  const [eventId, setEventId] = useState('')
  const [modal1, setModal1] = useState(false)
  const [items, setItems] = useState(CalendarDataList)
  const [isAm, setIsAm] = useState(true)
  const [currentdate, setCurrentDate] = useState(moment(new Date()).format("YYYY/MM/DD"))
  const [day, setDay] = useState("")
  const [timeToSend, setTimeToSend] = useState("")

  const [date, setDate] = useState(new Date())
  const [open, setOpen] = useState(false)
  const dispatch = useDispatch()
  const navigation = useNavigation()
  useEffect(() => {
    calendarListt()
  }, [])
  useEffect(() => {
    if (CalendarDataList.length != 0) {
      const sorted = CalendarDataList.sort((a, b) => {
        const dateA = new Date(`${a.created_at}`).valueOf();
        const dateB = new Date(`${b.created_at}`).valueOf();
        if (dateB > dateA) {
          return 1; // return -1 here for DESC order
        }
        return -1 // return 1 here for DESC Order
      });
      setItems(sorted)
    }
  }, [CalendarDataList])
  
  const calendarListt = () => {
    dispatch(getCalendarData(token)).then(res => {
      // console.log(res);
    }).catch(e => {
      console.log(e);
      errorToast("Network Error")
    })
  }
  const schduleNotification = (date) => {
    PushNotification.createChannel(
      {
        channelId: 'reminders', // (required)
        channelName: 'Task reminder notifications', // (required)
        channelDescription: 'Reminder for any tasks',
      },
      (created) => {
        PushNotification.localNotificationSchedule({
          title: eventTitle,
          date: date,
          message: eventDescription,
          allowWhileIdle: false,
          channelId: "reminders"
        });
      },
    );
    // successToast("sent")
  }
  const handleClick = (type) => {
    setCreatingType(type)
    setModal1(false)
    setModal2(true)
  }

  const renderEmptyDate = () => {
    return (
      null
    );
  }

  const rowHasChanged = (r1, r2) => {
    return r1.name !== r2.name;
  }

  const dayPress = (item) => {
    setDateString(item.dateString)
    setModal1(true)
    setModal2(true)
    setBtnName(false)

  }
  const timeToString = (time) => {
    const date = new Date(time);
    return date.toISOString().split('T')[0];
  }
  const resetData = () => {
    setEventTitle("")
    setEventDescription("")
    setHours("")
    setMinutes("")
    setTimeToSend("")
  }
  const handleAdd = () => {
    if (eventTitle.trim() == "") {
      errorToast("Please Enter Title")
    } else if (eventDescription.trim() == "") {
      errorToast("Please Enter Description")
    }
    else if (timeToSend == "") {
      errorToast("Please Select-Time")
    }
    else {
      setLoader(true)
      var formdata = new FormData()
      formdata.append("title", eventTitle)
      formdata.append("description", eventDescription)
      formdata.append("height", 12)
      formdata.append("day", dateString)
      formdata.append("starts_at", timeToSend)
      formdata.append("type", creatingType)
      console.log("formdata us the", formdata)
      dispatch(eventCellCalender(token, formdata)).then(async res => {
        await console.log(res, "uoooiiouoij");
        if (res.success) {
          calendarListt()
          setLoader(false)
          setModal2(false)
          resetData()
          successToast(res.message)
          // schduleNotification(date)
        } else {
          // alert(res)
          setLoader(false)
          errorToast(res.message)
        }
      }).catch(e => {
        console.log(e, "dgdgdsgsdgsdg");
        setLoader(false)
        errorToast("Network error")

      })
    }
  }

  const handleUpdate = () => {
    if (eventTitle.trim() == "") {
      errorToast("Please Enter Title")
    } else if (eventDescription.trim() == "") {
      errorToast("Please Enter Description")
    }
    else if (timeToSend == "") {
      errorToast("Please Select-Time")
    }
    else {
      setLoader(true)
      var objToSend = JSON.stringify({
        title: eventTitle,
        description: eventDescription,
        height: 12,
        day: dateString,
        type: creatingType,
        starts_at: timeToSend
      })
      console.log(objToSend, "askggsalkajkshakljsfhkaljshkajsf", eventId);
      dispatch(updateCalendarEvent(token, objToSend, eventId)).then(async res => {
        await console.log(res, "uoooiiouoij");
        if (res.success) {
          calendarListt()
          setLoader(false)
          setModal2(false)
          resetData()
          successToast(res.message)

        } else {
          // alert(res)
          setLoader(false)
          errorToast(res.message)
        }
      }).catch(e => {
        console.log(e, "dgdgdsgsdgsdg");
        setLoader(false)
        errorToast("Network error")

      })
    }
  }
  const handleDelete = () => {
    setLoader(true)
    dispatch(deleteCalendarEvent(token, eventId)).then(res => {
      console.log(res, "delete event response");
      calendarListt()
      setLoader(false)
      setModal2(false)
      resetData()
    }).catch(e => {
      errorToast("Network Error")
      console.log(e);
    })
  }

  const handlePress = (item) => {
    setModal2(true)
    setEventTitle(item.title)
    setEventDescription(item.description)
    setBtnName(true)
    setDateString(item.day)
    setCreatingType(item.type)
    setEventId(item.id)
    setTimeToSend(item.starts_at)
    console.log(item.day, "item.item.day");
  }

  const renderCustomView = (item, index) => {
    const fontSize = scale(13)
    const color = 'black'
    return (
      <ScrollView showsVerticalScrollIndicator={false}>
        {item.map((el, ind) => {
          return (
            <TouchableOpacity
              onPress={() => handlePress(el)}
              style={[styles.item, { minHeight: scale(80) }]}
            >
              <View style={{ flexDirection: "row" }}>
                <View style={styles.renderLeftBox}>
                  <Text style={styles.itemDate}>
                    {moment(el.day).format("DD")}</Text>
                  <Text style={styles.itemDay}>
                    {moment(el.day).format("ddd")}</Text>
                </View>
                <View style={{ width: "70%" }}>

                  <Text style={styles.itemTime}>{moment(el.starts_at).format("hh:mm A")}</Text>
                  <Text numberOfLines={1} style={styles.itemTitle}>{el.title}</Text>
                  <Text numberOfLines={2} style={styles.itemDescription}>{el.description}</Text>
                </View>
              </View>
            </TouchableOpacity>
          )
        })}
      </ScrollView>
    )
  }

  const handleCancel = () => {
    resetData()
    setModal2(false)
  }
  return (
    <SafeAreaView style={commonStyles.mainContainer}>
      <MainHeader menu />
      <View style={styles.headerBox}>
        <TouchableOpacity onPress={() => {

          navigation.goBack();
        }} >
          <Image
            source={images.leftArrow}
            style={styles.menu}
            resizeMode='stretch'
          />
        </TouchableOpacity>
        <Text style={styles.title}>Calendar</Text>
      </View>
      {loader && <LoadingComponent />}

      {
        modal2 && (
          <Modal
            animationType='fade'
            transparent={true}
            visible={modal2}
            onRequestClose={() => {
              setModal2(!modal2);
            }}
          >
            {
              modal1 ?
                <View style={styles.centeredView}>
                  <View style={styles.modalView}>
                    <Text onPress={() => handleClick("event")} style={styles.modalText}>Add Event!</Text>
                    <Text onPress={() => handleClick("appointment")} style={styles.modalText}>Add Therapy Appointment!</Text>

                  </View>
                </View>
                :
                <View style={styles.centeredView}>
                  <View style={styles.modalView}>
                    <TextInput
                      style={styles.inputTitle}
                      value={eventTitle}
                      onChangeText={(text) => setEventTitle(text)}
                      placeholder='Title'
                    />
                    <TextInput
                      style={styles.inputText}
                      multiline={true}
                      value={eventDescription}
                      onChangeText={(text) => setEventDescription(text)}
                      textAlignVertical='top'
                      placeholder='Description'
                    />
                    <View>
                      <Text onPress={() => setOpen(true)} style={styles.modalText}> Select-Time</Text>
                      <Text style={[styles.modalText, {
                        marginTop: scale(-15),
                        left: scale(10)
                      }]}>{timeToSend != "" && moment(timeToSend).format("hh:mm A")}</Text>
                      <DatePicker
                        modal
                        open={open}
                        mode="time"
                        date={date}
                        onConfirm={(date) => {
                          setOpen(false)
                          setTimeToSend(date.toString())
                          setDate(date)
                          console.log(date);
                        }}
                        onCancel={() => {
                          setOpen(false)
                        }}
                      />
                    </View>
                    <View style={styles.btnBox}>
                      <CommonButtons title={btnName ? "Update" : "Add"} customStyle={{ height: scale(35), width: "30%" }}
                        onPress={() => !btnName ? handleAdd() : handleUpdate()} />
                      <CommonButtons title={"Cancel"} customStyle={{ height: scale(35), width: "30%" }}
                        onPress={() => handleCancel()}
                      />
                    </View>
                    {
                      btnName &&
                      <CommonButtons title={"Delete"} customStyle={{ height: scale(35), width: "30%", marginTop: scale(10) }}
                        onPress={() => handleDelete()}
                      />
                    }
                  </View>
                </View>
            }
          </Modal>
        )
      }
      <View style={styles.calenderBox}>
        <Agenda
          testID={"agenda"}
          items={items}
          onDayPress={(item) => dayPress(item)}
          renderEmptyDate={renderEmptyDate}
          rowHasChanged={rowHasChanged}
          showClosingKnob={true}
          keyExtractor={item=>item.id}
          renderList={(item, index) => renderCustomView(item.items, index)}
        />
      </View>
    </SafeAreaView>
  )
}

export default Calendar

const styles = StyleSheet.create({
  item: {
    backgroundColor: 'white',
    flex: 1,
    borderRadius: 5,
    padding: 10,
    // marginRight: 10,
    // marginTop: 17,
    maxHeight: scale(100)
  },
  emptyDate: {
    height: 15,
    flex: 1,
    paddingTop: 30
  },
  calenderBox: {
    height: windowHeight / 1.5,
    width: windowWidth - scale(30),
    alignSelf: "center",
  },
  headerBox: {
    height: scale(80),
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: scale(20),
  },
  menu: {
    height: 18,
    width: 15,
    borderRadius: 20,
    overflow: "hidden",

  },
  title: {
    fontSize: moderateScale(20) / fontScalingFactor,
    alignSelf: "center",
    // marginTop: scale(20),
    color: colors.signUpBtn,
    fontWeight: "700",
    fontFamily: "PlusJakartaSans-Italic-VariableFont_wght",
    marginLeft: "30%"
  },
  centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 22,
  },
  addingEventBox: {
    height: scale(200),
    width: "90%",
    // backgroundColor: "green",
  },
  modalView: {
    margin: 20,
    backgroundColor: "white",
    borderRadius: 20,
    minHeight: scale(100),
    maxHeight: windowHeight / 2,
    width: "90%",
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
    width: windowWidth - 50
  },
  button: {
    borderRadius: 20,
    padding: 10,
    elevation: 2
  },
  buttonOpen: {
    backgroundColor: "#F194FF",
  },
  buttonClose: {
    backgroundColor: "#2196F3",
  },
  textStyle: {
    color: "white",
    fontWeight: "bold",
    textAlign: "center"
  },
  modalText: {
    marginBottom: 15,
    textAlign: "center"
  },
  modalText: {
    color: colors.signUpBtn,
    fontSize: moderateScale(18) / fontScalingFactor,
    padding: scale(10)
  },
  inputText: {
    height: "30%",
    color: colors.greyText,
    fontSize: scale(14) / fontScalingFactor,
    width: "90%",
    marginBottom: scale(10)
  },
  inputTitle: {

    height: "15%",
    color: colors.black,
    fontSize: scale(12) / fontScalingFactor,
    width: "90%",
    marginBottom: scale(5)
  },
  timeEntered: {
    height: scale(30),
    color: colors.greyText,
    fontSize: scale(12) / fontScalingFactor,
    width: scale(30), textAlign: 'left',
    marginBottom: scale(10),
    // backgroundColor: "red"
  },
  btnBox: { flexDirection: "row", justifyContent: "space-evenly", width: "100%" },
  renderLeftBox: { width: "25%", minHeight: scale(100), alignItems: "center" },
  itemDate: { color: colors.greyText, fontSize: moderateScale(26), marginTop: scale(10) },
  itemDay: { color: colors.greyText, fontSize: moderateScale(20), marginTop: scale(-4) },
  itemTime: {
    fontSize: (moderateScale(16)), color: colors.time, paddingLeft: scale(6),
    paddingTop: scale(10)
  },
  itemTitle: {
    fontSize: moderateScale(20), color: colors.black, paddingLeft: scale(6),
    paddingTop: scale(2)
  },
  itemDescription: {
    fontSize: moderateScale(13),
    color: colors.signUpBtn, paddingLeft: scale(6)
    , paddingTop: scale(2), fontWeight: "300"
  }

});




