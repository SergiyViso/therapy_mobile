import { Image, SafeAreaView, ScrollView, StyleSheet, Text, View } from 'react-native'
import React, { useEffect, useState } from 'react'
import { commonStyles, errorToast, fontScalingFactor, windowHeight, windowWidth } from '../../components/CommonStyles';
import MainHeader from '../../components/MainHeader';
// import { BarChart, LineChart, PieChart } from "react-native-gifted-charts";
import { moderateScale, scale } from 'react-native-size-matters';

import {
  LineChart,
} from "react-native-chart-kit";
import { colors } from '../../components/Colors';
import DropDownComponent from '../../components/DropDownComponent';
import { useDispatch, useSelector } from 'react-redux';
import CommonButtons from '../../components/CommonButtons';
import { images } from '../../components/Images';
import { getSymptomToTrack } from '../../../redux/actions/mainAction';
import moment from 'moment';

const SymptomsGraph = () => {
  const userSymptomList = useSelector(state => state.main.userSymptomList)
  const graphSymptomList = useSelector(state => state.main.graphSymptomList)
  const token = useSelector(state => state.auth.accessToken)
  const [selectedSymptom, setSelectedSymptom] = useState(null);
  const [selectedIndex, setSelectedIndex] = useState(2)
  console.log(graphSymptomList, "graphSymptomListgraphSymptomList123");
  const [symptomId, setsymptomId] = useState("")
  const [innerData, setInnerData] = useState([3,4,2,6,8,4,7])
  // const [barData1, setBarData] = useState({
  //   labels: ["January", "Feb", "Mar", "Apr", "May", "Jun", "Jul","Aug","Sep","Oct","Nov","Dec"],
  //   datasets: [
  //     {
  //       data: [
  //         1,
  //         1,
  //         1,
  //         1,
  //         1,
  //         1,
  //         1,
  //         1,
  //         1,
  //         1,
  //         1,
  //         10,
  //       ],
  //       color: (opacity = 1) => `rgba(134, 233, 244, ${opacity})`, // optional
  //       strokeWidth: 1
  //     },
  //   ],
  // })

  const [labelss, setLabels] = useState(["Sun","Mon","Tues","Wed","Thus","Fri","Sat"])
  const barData1 = {
    labels: labelss,
    datasets: [
      {
        data: innerData,
        color: (opacity = 1) => `rgba(134, 233, 244, ${opacity})`, // optional
        strokeWidth: 1
      },
    ],
  }
  
  const btns = [
    { id: 0, title: "Yearly" },
    { id: 1, title: "Monthly" },
    { id: 2, title: "Weekly" },
  ]

  // console.log(graphSymptomList,"graphSymptomListgraphSymptomList");

  const dispatch = useDispatch()
  useEffect(() => {
if (graphSymptomList.length != 0) {
  
  handleData()
}

  }, [graphSymptomList])


  async function handleData() {

        // let arr = data
        let arr = [...graphSymptomList]
        const ratings = await arr.map((el, ind) => {
          innerData.splice(ind, 1, "el.rating")
          console.log(el.rating);
          return el.rating
        })
        const months = await arr.map((el, ind) => {
          console.log(el.month);
          return el.month
        })
        // alert(ratings)
        setInnerData(ratings),
        setLabels(months)
  }

  const getSymptomApi = async () => {
    if (symptomId == "") {
      errorToast("Please select Symptom to Track!")
    } else {

      var formdata = new FormData()
      formdata.append("tabValue", "year")
      formdata.append("year", "2023")
      await dispatch(getSymptomToTrack(token, formdata, symptomId)).then(res => {
        console.log(JSON.stringify(res), "iuyuiyoiioiuoiiou");
      })
    }
  }
  //  useEffect(()=>{
  //      let arr =  [...]
  //  },[])

  const handleSectedBtn = (index) => {
    setSelectedIndex(index)
    getSymptomApi()
  }


  return (
    <SafeAreaView style={commonStyles.mainContainer}>
      <MainHeader backIcon />
      <Text style={styles.screenTitle}>Monitor your progress</Text>
      <ScrollView>


      <View style={styles.innerContentBox}>
        <DropDownComponent value={selectedSymptom} onSetValue={(value) => setSelectedSymptom(value)}
          idOfSelectedItem={(id) => setsymptomId(id)} listToRender={userSymptomList}
          placeholder="Select Symptoms"
        />
        <View style={styles.btnBox}>
          {
            btns.map((item, index) => {
              return (
                <CommonButtons
                  title={item.title}
                  customStyle={styles.btnStyle(index, selectedIndex)}
                  customText={styles.btnText}
                  onPress={() => handleSectedBtn(index)}
                />
              )
            })
          }
        </View>
        <LineChart
          data={barData1}
          width={windowWidth - scale(40)} // from react-native
          height={windowHeight / 3}
          // yAxisLabel="$"
          withHorizontalLines={true}
          // yAxisSuffix="%"
          // verticalLabelRotation={50}
          yAxisInterval={0.2} // optional, defaults to 1
          // onDataPointClick={(res)=>alert(JSON.stringify(res))}
          chartConfig={{
            backgroundColor: colors.buttonColor,
            backgroundGradientFrom: colors.signUpBtn,
            backgroundGradientTo: colors.buttonColor,
            decimalPlaces: 0, // optional, defaults to 2dp
            color: (opacity = 1) => `rgba(255, 255, 255, 0.4)`,
            labelColor: (opacity = 1) => `rgba(244, 255, 255, 1)`,
            style: {
              borderRadius: 16,

            },
            propsForDots: {
              r: "6",
              strokeWidth: "4",
              stroke: colors.white
            }
          }}
          // bezier
          style={{
            // marginVertical: 8,
            borderRadius: 16,

            // marginHorizontal: scale(10)
          }}
        />
        <Image
          source={images.monitorrProgress}
          style={{ height: windowHeight / 4, width: windowWidth / 1.3, top: 10, alignSelf: "center" }}
          resizeMode='stretch'
        />
      </View>
              </ScrollView>
    </SafeAreaView>
  )
}

export default SymptomsGraph

const styles = StyleSheet.create({
  screenTitle: {
    fontSize: moderateScale(20) / fontScalingFactor,
    alignSelf: "center",
    fontWeight: "600",
    color: colors.signUpBtn, marginVertical: scale(10)
  },
  innerContentBox: {
    width: windowWidth - scale(40),
    alignSelf: "center",
    // backgroundColor: "#87587822",
  },
  btnBox: {
    flexDirection: "row",
    justifyContent: "space-evenly",
    alignItems: "center",
    height: scale(25),
    marginHorizontal: scale(10),
    marginBottom: scale(20),
    marginTop: scale(10),
    // backgroundColor: "#fff"
  },
  btnStyle: (index, selectedIndex) => {
    return {
      backgroundColor: index == selectedIndex ? colors.signUpBtn : colors.buttonColor,
      borderRadius: scale(6),
      width: windowWidth / 4.5,
      alignSelf: "center",
      height: scale(25)
    }
  },
  btnText: { fontSize: moderateScale(10) / fontScalingFactor }
})