import { Image, SafeAreaView, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native'
import React, { useEffect, useState } from 'react'
import { commonStyles, errorToast, fontScalingFactor, successToast, windowHeight, windowWidth } from '../../components/CommonStyles'
import MainHeader from '../../components/MainHeader'
import { moderateScale, scale } from 'react-native-size-matters'
import { images } from '../../components/Images'
import { colors } from '../../components/Colors'
import CommonButtons from '../../components/CommonButtons'
import NotesRating from '../../components/NotesRating'
import DropDownComponent from '../../components/DropDownComponent'
import { useDispatch, useSelector } from 'react-redux'
import PushNotification from 'react-native-push-notification';
import Notification from '../../components/Notification'
import { addingGoals, deletingGoal, getUserGoals, getUserNotes } from '../../../redux/actions/mainAction'
import DatePicker from 'react-native-date-picker'
PushNotification.configure({
    // (optional) Called when Token is generated (iOS and Android)
    onRegister: function (token) {
        // console.log('TOKEN:', token);
    },
    onNotification: function (notification) {
        console.log('NOTIFICATION:', notification);
    },
    popInitialNotification: true,
    requestPermissions: true,
    // IOS ONLY (optional): default: all - Permissions to register.
    permissions: {
        alert: true,
        badge: false,
        sound: false,
    },
});


const Goals = (props) => {
    const [addGoal, setAddGoal] = useState("")
    const [deletingId, setDeletingId] = useState("")
    const [date, setDate] = useState(new Date())
    const [open, setOpen] = useState(false)
    const [deleteGoal, setDeleteGoal] = useState(null);
    const [modal1, setModal1] = useState(false)
    const token = useSelector(state => state.auth.accessToken)
    const goalsList = useSelector(state => state.main.userGoals)
    const userDetails = useSelector(state => state.auth.user)
    const dispatch = useDispatch()
    const schduleNotification = (date) => {
        PushNotification.createChannel(
            {
                channelId: 'reminders', // (required)
                channelName: 'Task reminder notifications', // (required)
                channelDescription: 'Reminder for any tasks',
            },
            (created) => { 
        PushNotification.localNotificationSchedule({
            title:'My notification title',
            date:date,
            message:'My notification Message',
            allowWhileIdle:false,
            channelId: "reminders"
          });
        },
        );
        successToast("sent")
    }

    const onAddingGoals = async () => {
        if (addGoal == "") {
            successToast("Please add your goal")
        }
        else {
            await dispatch(addingGoals(addGoal, token)).then(res => {
                console.log(res);
                if (res.success == true) {
                    successToast("Added Successfully")
                }else{
                    successToast(res.message)
                }
            }).catch(e => {
                errorToast(e.message)
            })
         await dispatch(getUserGoals(token))
            setAddGoal("")
        }
    }
    console.log(deletingId,"deletingIddeletingId");
    const onPressDelete = async () => {
        if (deletingId != "") {
            await dispatch(deletingGoal(deletingId, token)).then(res => {
                console.log(res,"deleting response ======>>>>>>>>>>");
                if (res.success == true) {
                    successToast(res.message)
                    setDeletingId("")
                }
            }).catch(e => {
                errorToast(e.message)
            })
            await dispatch(getUserGoals(token))
            await dispatch(getUserNotes(token))
        }
    }
    return (
        <SafeAreaView style={commonStyles.mainContainer}>
            <MainHeader backIcon />
            <ScrollView>
                <View style={styles.topBox}>
                    <Text
                    //  onPress={() => {
                    //     setModal1(true)
                    //     setOpen(true)
                    // }}
                     style={styles.topText}>Add or delete multiple
                        Fields according to
                        your Goals</Text>
                    <Image
                        source={images.goalsScreenImage}
                        style={styles.topImage}
                        resizeMode='stretch'
                    />
                </View>
                {
                    modal1 &&
                    <DatePicker
                        modal
                        open={open}
                        mode="time"
                        date={date}
                        onConfirm={(date) => {
                            setOpen(false)
                            // setTimeToSend(date.toString())
                            setDate(date)
                            console.log(date);
                        }}
                        onCancel={() => {
                            setOpen(false)
                        }}
                    />
                }
                <Text style={styles.addText}>Add</Text>
                <TextInput
                    value={addGoal}
                    onChangeText={(t) => setAddGoal(t)}
                    placeholder=''
                    style={styles.input}
                />
                <CommonButtons title={"Add"}
                    onPress={() => onAddingGoals()}
                    customStyle={styles.btnStyle} />
                <View style={styles.greyLine}></View>
                {
                    goalsList.length != 0 &&
                    <>
                        <Text style={[styles.addText, { marginTop: scale(-10) }]}>Delete</Text>
                        <DropDownComponent value={deleteGoal} onSetValue={(value) => setDeleteGoal(value)}
                            idOfSelectedItem={(id) => setDeletingId(id)} listToRender={goalsList}
                            placeholder="Improve my self-esteem"
                        />
                        <CommonButtons title={"Delete"} customStyle={styles.deleteBtn} leftIcon={images.whiteTrash}
                            onPress={() => onPressDelete()}
                        />
                    </>
                }
            </ScrollView>
        </SafeAreaView>
    )
}

export default Goals

const styles = StyleSheet.create({
    topBox: {
        height: scale(200),
        width: windowWidth - scale(30),
        alignSelf: "center",
        marginTop: scale(20),
        padding: scale(10)
    },
    topText: {
        fontSize: moderateScale(18) / fontScalingFactor,
        fontWeight: "700",
        fontFamily: "Plus Jakarta Sans",
        width: "50%",
        zIndex: 56,
        color: colors.signUpBtn,
        top: scale(20)
    },
    topImage: {
        position: "absolute",
        right: scale(10),
        top: scale(10),
        height: "100%",
        width: "60%"
    },
    addText: {
        alignSelf: "center",
        fontSize: moderateScale(16) / fontScalingFactor,
        fontWeight: "700",
        fontFamily: "Plus Jakarta Sans",
        color: colors.black,
        marginBottom: scale(8)
    },
    input: {
        height: scale(35),
        borderRadius: scale(10),
        borderWidth: 0.8, borderColor: colors.greyText,
        width: windowWidth - scale(50),
        alignSelf: "center",
        padding: scale(10)
    },
    btnStyle: {
        backgroundColor: colors.signUpBtn,
        width: windowWidth - scale(50),
        alignSelf: "center", marginTop: scale(10),
        height: scale(35)
    },
    deleteBtn: {
        backgroundColor: colors.buttonColor,
        width: windowWidth - scale(50),
        alignSelf: "center", marginTop: scale(10),
        height: scale(35)
    },
    greyLine: {
        height: 1,
        width: windowWidth,
        backgroundColor: colors.greyText,
        alignSelf: "center",
        marginVertical: scale(40)
    },
})