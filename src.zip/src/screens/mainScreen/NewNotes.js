import { Image, KeyboardAvoidingView, SafeAreaView, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native'
import React, { useRef, useState } from 'react'
import MainHeader from '../../components/MainHeader'
import { commonStyles, errorToast, fontScalingFactor, successToast, windowHeight, windowWidth } from '../../components/CommonStyles'
import { moderateScale, scale } from 'react-native-size-matters'
import { images } from '../../components/Images'
import { actions, RichEditor, RichToolbar } from 'react-native-pell-rich-editor';
import { colors } from '../../components/Colors'
import NotesRating, { NotesReviewOfLastWesk } from '../../components/NotesRating'
import Toast from 'react-native-toast-message'
import { useDispatch, useSelector } from 'react-redux'
import { deleteNotesById, getUserNotes, postUserNotes, updatingNote } from '../../../redux/actions/mainAction'
import LoadingComponent from '../../components/LoadingComponent'
import { useNavigation } from '@react-navigation/native'
import { notesQuestions } from '../../utils/utils'

const NewNotes = ({route}) => {
  const routeData = route.params.data
  const goalsList = useSelector(state => state.main.userGoals)
  const token = useSelector(state => state.auth.accessToken)
  const richText = useRef();
  const richTextCoupon = useRef();
  const [firstDropdownValue, setFirstDropdownValue] = useState(null);
  const [secondDropdownValue, setSecondDropdownValue] = useState(null);
  const [goalId, setGoalId] = useState(routeData.goal_id);
  const [questionId, setQuestionId] = useState(routeData.question_id);
  const [condition, setcondition] = useState('');
  const [notes, setNotes] = useState(routeData.description);
  const [answer, setAnswer] = useState(routeData.answer);
  const [previousWeekDescription, setPreviousWeekDescription] = useState(routeData.previous_week_description);
  const [upperrating, setUpperrating] = useState(routeData.weekly_rating)
  const [lowerrating, setLowerrating] = useState(routeData.goal_rating)
  const [loader, setLoader] = useState(false)
  const [title, setTitle] = useState(routeData.title)
  const dispatch = useDispatch()
  const navigation = useNavigation()
  // console.log(routeData,"routeDatarouteDatarouteData");
  const resetData = () => {
    setAnswer("")
    setTitle("")
    setNotes("")
    setQuestionId("")
    setGoalId("")
    setPreviousWeekDescription("")
  }
  const onPressSave = () => {
    if (title.trim() == '') {
      errorToast('Please enter Title')
    } else if (notes.trim() == '') {
      errorToast('Please enter Description')
    }
    else if (questionId == "") {
      errorToast('Please select Question')
    } else if (answer.trim() == "") {
      errorToast('Please write the answer to Selected Question')
    }
    else {
      setLoader(true)
      var formdata = new FormData();
      formdata.append("title", title);
      formdata.append("description", notes);
      formdata.append("question_id", "1");
      formdata.append("answer", answer);
      formdata.append("weekly_rating", upperrating);
      formdata.append("goal_id", goalId);
      formdata.append("goal_rating", lowerrating);
      formdata.append("previous_week_description", previousWeekDescription);
      dispatch(postUserNotes(token, formdata)).then(async(response) => {
        if (response.success == true) {
          setLoader(false)
          successToast("Added Successfully")
          console.log(response, "NotesPostResponse");
          resetData()
          await dispatch(getUserNotes(token))
          navigation.goBack()
        } else {
          errorToast(response.error)
          setLoader(false)
        }
      })
    }
  }

  const updateNote = () => {
    if (title.trim() == '') {
      errorToast('Please enter Title')
    } else if (notes.trim() == '') {
      errorToast('Please enter Description')
    }
    else if (questionId == "") {
      errorToast('Please select Question')
    } else if (answer.trim() == "") {
      errorToast('Please write the answer to Selected Question')
    }
    else {
      setLoader(true)
      var objToSend = JSON.stringify({
        title:title,
        description:notes,
        question_id:questionId,
        answer:answer,
        weekly_rating:upperrating,
        goal_id:goalId,
        goal_rating:lowerrating,
        previous_week_description:previousWeekDescription,
      })
      dispatch(updatingNote(token, objToSend,routeData.id)).then(async(response) => {
        if (response.success == true) {
          setLoader(false)
          successToast("Updated Successfully")
          await dispatch(getUserNotes(token))
          navigation.goBack()
        } else {
          errorToast(response.error)
          setLoader(false)
        }
      })
    }
  }
  const deleteNotes = ()=>{
    if (route.params.noteStatus == "new") {
      navigation.goBack()
      resetData()
    }else{
      dispatch(deleteNotesById(token,routeData.id)).then( async (res)=>{
        if (res.success == true) {
          await dispatch(getUserNotes(token)).then(res=>{
            console.log(JSON.stringify(res),"usernotessssss");
          })
          successToast(res.message)
          navigation.goBack()
        }
      }).catch(e=>{
        errorToast(e.message)
      })
    }
  }
  return (
    <SafeAreaView style={commonStyles.mainContainer}>
      <MainHeader backIcon />
      <ScrollView>
        {loader && <LoadingComponent />}
        <View style={styles.notesBox}>
          <TextInput
            multiline
            value={title}
            onChangeText={(t) => setTitle(t)}
            style={styles.title}
            placeholder='The beginning of time'
            placeholderTextColor={colors.greyText}
          />
          <TextInput
            value={notes}
            multiline
            textAlignVertical='top'
            onChangeText={(t) => setNotes(t)}
            style={styles.notes}
            placeholderTextColor={colors.greyText}
            placeholder='This is where your note will be. It’ll be housed here. You’ll save your note here. Type your memories here. Write down your thoughts.'
          />
        </View>
        <View style={{ marginTop: 20 }}>
          <View
            style={{
              borderWidth: 1,
              borderColor: '#D3D3D3',
              backgroundColor: '#ffff',
              width:windowWidth-scale(40),
              alignSelf:"center"
            }}>
            <RichToolbar
              style={{ backgroundColor: '#fff', alignSelf: 'flex-start' }}
              editor={richTextCoupon}
              androidLayerType="software"
              androidHardwareAccelerationDisabled={true}
              actions={[
                actions.setBold,
                actions.setItalic,
                actions.insertOrderedList,
                actions.insertBulletsList,
                actions.insertLink,
              ]}
            />
          </View>
          <KeyboardAvoidingView
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
            style={{
              borderWidth: 1,
              borderColor: '#D3D3D3',
              backgroundColor: '#fff',
              minHeight: scale(100),
              width:windowWidth-scale(40),
              alignSelf:"center"
            }}>
            <RichEditor
              ref={richTextCoupon}
              androidLayerType="software"
              value={notes}
              androidHardwareAccelerationDisabled={true}
              onChange={descriptionText => {
                setcondition(descriptionText);
                console.log(descriptionText);
              }}
              style={{ height: 10 }}

            />
          </KeyboardAvoidingView>
        </View>
        <NotesRating
          value={firstDropdownValue}
          onSetValue={(value) => setFirstDropdownValue(value)}
          list={notesQuestions}
          idOfSelectedItem={(id) => setQuestionId(id)}
          rating={(r) => setUpperrating(r)}
          onChangeValue={(text) => setAnswer(text)}
          answer = {answer}
          notesQuestionId={route.params.noteStatus == "new"? "": routeData.question_id}
          ratingCount = {routeData.weekly_rating == null || routeData.weekly_rating == false ? "9":routeData.weekly_rating}
        />
        <NotesReviewOfLastWesk
          value={secondDropdownValue}
          onSetValue={(value) => setSecondDropdownValue(value)}
          list={goalsList}
          idOfSelectedItem={(id) => setGoalId(id)}
          rating={(r) => setLowerrating(r)}
          onChangeValue={(t) => setPreviousWeekDescription(t)}
          previousDescription = {previousWeekDescription}
          lastGoalId={route.params.noteStatus == "new"? "":routeData.goal == null ? "" :  routeData.goal_id}
          ratingCount = {routeData.goal_rating == null || routeData.goal_rating == false ? "9":routeData.goal_rating}
        />
        <View style={styles.del_save_Icon_Box}>
        <TouchableOpacity style={styles.deleteNotesBox} 
        onPress={()=>deleteNotes()}
        >
          <Image
            source={images.trashIcon}
            style={styles.trashIcon}
          />
          </TouchableOpacity>
          <TouchableOpacity style={styles.saveNotesBox} 
          onPress={() => {route.params.noteStatus == "new" ? onPressSave(): updateNote()}}
          >
            <Image
              source={images.saveNotes}
              style={styles.saveNotes}
            />
          </TouchableOpacity>
        </View>
        <View style={{ height: scale(20) }}></View>
      </ScrollView>
    </SafeAreaView>
  )
}

export default NewNotes

const styles = StyleSheet.create({
  title: {
    maxHeight: 80,
    fontSize: moderateScale(25)/fontScalingFactor,
    width: "95%",
    marginBottom: scale(10),

  },
  notes: {
    minHeight: 40,
    fontSize: moderateScale(15)/fontScalingFactor,
    width: "95%",
    maxHeight: windowHeight / 4,
    // backgroundColor: "red"
  },
  reviewText: {
    height: scale(100),
    fontSize: moderateScale(15)/fontScalingFactor,
    width: "100%",
    borderRadius: scale(10),
    borderWidth: 1,
    borderColor: colors.black,

  },
  notesBox: {
    width: windowWidth - scale(40),
    alignSelf: "center",
    marginTop: scale(30),
  },
  del_save_Icon_Box: {
    height: scale(50),
    width: windowWidth,
    flexDirection: "row",
    alignItems: "center",
  },
  trashIcon: { height: 35, width: 35,  },
  saveNotesBox: { height: 50, width: 50, position: "absolute", right: scale(35),},
  deleteNotesBox: { height: 50, width: 50, position: "absolute", right: scale(90),alignItems:"center",justifyContent:"center"  },
  saveNotes: { height: 50, width: 50 },
  textNormal: (size, color, weight, customStyles) => {
    return {
      fontSize: size,
      fontFamily: 'Poppins-Regular',
      color: color,
      fontWeight: weight,
      ...customStyles
    }
  },
  dropDownTitle: {
    fontSize: moderateScale(20)/fontScalingFactor,
    fontWeight: "600",
    fontFamily: "Inter",
    marginVertical: scale(12)
  },
  bottomContentBox: {
    width: windowWidth - scale(70),
    alignSelf: "center",
    // backgroundColor: "#76767755"
  },



  dropdown: {
    height: scale(40),
    // borderColor: 'gray',
    borderWidth: 0.5,
    borderRadius: 8,
    paddingHorizontal: 8,
    marginBottom: scale(10)
  },
  icon: {
    marginRight: 5,
    height: scale(8),
    width: scale(12)
  },
  label: {
    position: 'absolute',
    backgroundColor: 'white',
    left: 22,
    top: 8,
    zIndex: 999,
    paddingHorizontal: 8,
    fontSize: 14,
  },
  placeholderStyle: {
    fontSize: 16,
  },
  selectedTextStyle: {
    fontSize: 16,
  },
  iconStyle: {
    width: 20,
    height: 20,
  },
  inputSearchStyle: {
    height: 40,
    fontSize: 16,
  },

})