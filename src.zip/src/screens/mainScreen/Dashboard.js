import { Image, ImageBackground, SafeAreaView, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import React, { useEffect, useState } from 'react'
import { commonStyles, fontScalingFactor, windowHeight, windowWidth } from '../../components/CommonStyles'
import StatusBarComponent from '../../components/StatusBarComponent'
import { colors } from '../../components/Colors'
import { images } from '../../components/Images'
import { moderateScale, scale } from 'react-native-size-matters'
import DashboardHeader from '../../components/DashboardHeader'
import { boxes } from '../../utils/utils'
import messaging from '@react-native-firebase/messaging'
import { CalenderBox, ChallengesBox, GoalBox, MonitorProgessBox } from '../../components/DashBoardBoxes'
import { useDispatch, useSelector } from 'react-redux'
import { getSymptomToTrack, getUserGoals, getUserHomeWork, getUserNotes, getUserSymptoms } from '../../../redux/actions/mainAction'
import LoadingComponent from '../../components/LoadingComponent'
//import Orientation from 'react-native-orientation-locker'
import { useIsFocused } from '@react-navigation/native'
const Dashboard = (props) => {
    const token = useSelector(state => state.auth.accessToken)
    const [loader, setLoader] = useState(false)
    const dispatch = useDispatch()
    useEffect(() => {
        //Orientation.lockToPortrait();
        gettingUserData()
    }, [])

    const gettingUserData = async () => {
        setLoader(true)
        await dispatch(getUserGoals(token))
        await dispatch(getUserSymptoms(token))
        await dispatch(getUserNotes(token))
        await dispatch(getUserHomeWork(token))
        setLoader(false)
    }

    return (
        <SafeAreaView style={commonStyles.mainContainer}>
            <StatusBarComponent backgroundColor={colors.signUpBtn} color />
            <DashboardHeader />
            {
                loader && <LoadingComponent />
            }
            <View style={styles.threeBoxes}>
                {
                    boxes.map((item, index) => {
                        return (
                            <TouchableOpacity key={index} onPress={() => props.navigation.navigate("IndividualTherapy")}>
                                <ImageBackground style={styles.boxes}
                                    source={images.redBox}
                                    resizeMode='stretch'
                                >
                                    <Text style={styles.boxTitle}>{item.title1}</Text>
                                    <Text style={styles.boxTitle}>{item.title2}</Text>
                                    <View style={{ flexDirection: "row" }}>
                                        <Text style={styles.clickHere}>Click here</Text>
                                        <Image
                                            source={images.rightArrow}
                                            style={{ height: 12, width: 12, left: 4, top: 2 }}
                                        />
                                    </View>
                                </ImageBackground>
                            </TouchableOpacity>
                        )
                    })
                }
            </View>
            <ScrollView>
                <CalenderBox />
                <View style={{
                    flexDirection: "row", justifyContent: "space-between", paddingHorizontal: scale(30),
                    height: windowHeight * 0.17, alignSelf: "center"
                }}>
                    {/* <ChallengesBox /> */}
                    <GoalBox />
                </View>
                <MonitorProgessBox />
                <View style={styles.commonBox}></View>
            </ScrollView>
        </SafeAreaView>
    )
}

export default Dashboard

const styles = StyleSheet.create({
    threeBoxes: {
        // height:scale(80),
        width: windowWidth - scale(50),
        alignSelf: "center",
        top: -scale(25),
        flexDirection: "row"
    },
    boxes: {
        height: scale(70),
        width: windowWidth / 3.8,
        marginHorizontal: 4,
        // backgroundColor:colors.buttonColor,
        borderRadius: 10,
        padding: moderateScale(8),
        justifyContent: "center"
    },
    boxTitle: {
        fontSize: moderateScale(14) / fontScalingFactor,
        color: colors.white,
        fontWeight: "600"
    },
    clickHere: {
        fontSize: moderateScale(10) / fontScalingFactor,
        color: colors.white
    },
    commonBox: {
        flexDirection: "row",
        height: scale(70),
        width: windowWidth - scale(60),
        alignSelf: "center",
        // backgroundColor: "#76546756",
        marginVertical: scale(10),
        borderRadius: moderateScale(10),
        alignItems: "center"
    },
    clickHereBox: {
        flexDirection: "row", alignItems: "center",

    }
})