import { FlatList, Image, SafeAreaView, StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import React, { useState } from 'react'
import { commonStyles, fontScalingFactor, windowWidth } from '../../components/CommonStyles'
import MainHeader from '../../components/MainHeader'
import { moderateScale, scale } from 'react-native-size-matters'
import { images } from '../../components/Images'
import { colors } from '../../components/Colors'
import { therapyList, titles } from '../../utils/utils'

const NotificationScreen = (props) => {
  const [title, setTitles] = useState(titles)
  const [isHide, setIsHide] = useState(false)

  const handlePress = (index) => {
    if (index == 1) {
      setIsHide(true)
    } else {
      setIsHide(false)
    }
    let newArr = [...title]
    newArr.map((item, ind) => {
      index == ind ? item.isSelected = true : item.isSelected = false
      return { ...item }
    })
    setTitles(newArr)
  }
  const renderNotifications = ({ item }) => {
    return (
      <TouchableOpacity style={styles.notificationBox} >
        <View style={styles.textBox}>
          <Text style={styles.notificationTitle}>{item.title}</Text>
          <Text style={styles.notificationDes}>{item.description}</Text>
        </View>
        <View style={styles.timeBox}>
          <Text style={styles.notificationTime}>{item.notificationAt}</Text>
        </View>
      </TouchableOpacity>
    )
  }
  return (
    <SafeAreaView style={commonStyles.mainContainer}>
      <MainHeader menu />
      <View style={styles.lowerHeader}>
        <TouchableOpacity onPress={() => props.navigation.goBack()}>
          <Image
            source={images.redBackIcon}
            style={styles.redBackIcon}
            resizeMode='stretch'
          />
        </TouchableOpacity>
        <Text style={styles.mainTitle}>Notifications</Text>
      </View>
      <View style={styles.titlesBox}>
        {
          title.map((item, index) => {
            return (
              <>
                <View>
                  <Text onPress={() => handlePress(index)} style={styles.title(item.isSelected)}>{item.title}</Text>
                  {
                    item.isSelected &&
                    <View style={styles.blueLine(item)}></View>
                  }
                </View>
                {
                  item.count &&
                  <View style={styles.countCircle}>
                    <Text style={{ fontSize: moderateScale(10) / fontScalingFactor, color: colors.white }}>{item.count}</Text>
                  </View>
                }

              </>
            )
          })
        }
      </View>
      {
        !isHide &&
        <FlatList
          data={therapyList}
          renderItem={renderNotifications}
        />
      }
    </SafeAreaView>
  )
}

export default NotificationScreen

const styles = StyleSheet.create({
  lowerHeader: {
    flexDirection: "row",
    height: scale(30),
    width: windowWidth - scale(30),
    alignSelf: "center",
    marginTop: scale(20),
    paddingHorizontal: scale(10),
    alignItems: "center"
  },
  redBackIcon: {
    height: scale(15),
    width: scale(10)
  },
  mainTitle: {
    color: colors.signUpBtn,
    fontSize: moderateScale(20) / fontScalingFactor,
    alignSelf: "center",
    fontWeight: "700",
    paddingLeft: "30%",
    // backgroundColor:"red"
  },
  titlesBox: {
    flexDirection: "row",
    height: scale(40),
    width: windowWidth - scale(30),
    alignSelf: "center",
    marginTop: scale(20),

    alignItems: "center",
    // backgroundColor: "grey"
  },
  title: (isSelected) => {
    return {

      color: colors.signUpBtn,
      fontSize: moderateScale(13) / fontScalingFactor,
      // alignSelf: "center",
      fontWeight: "400",
      marginRight: scale(40),
      marginLeft: scale(10),
      // textDecorationLine:isSelected?"underline":"none"

    }
  },
  countCircle: {
    height: scale(18),
    width: scale(18),
    borderRadius: 10,
    backgroundColor: colors.buttonColor,
    marginLeft: scale(-35),
    alignItems: "center",
    justifyContent: "center"
  },
  blueLine: (item) => {
    return {

      height: 1,
      width: item.title == "Therapy" ? scale(70) : scale(100),
      backgroundColor: colors.signUpBtn,
      marginTop: scale(5),
      position: "absolute", bottom: -5
    }
  },
  notificationBox: {
    height: scale(60),
    width: "100%",
    marginVertical: 10,
    flexDirection: "row",
    width: windowWidth - scale(40),
    alignSelf: "center"
  },
  textBox: {
    height: "100%",
    width: "80%",
    justifyContent: "center",
    padding: scale(4)
  },
  timeBox: {
    height: "100%",
    width: "20%",
    justifyContent: "center",
    alignItems: "center",
    textAlign: "center"
  },
  notificationTitle: {
    fontSize: moderateScale(13) / fontScalingFactor,
    fontWeight: "700",
    fontFamily: "Inter",
    color: colors.black
  },
  notificationDes: {
    fontSize: moderateScale(9) / fontScalingFactor,
    fontWeight: "400",
    fontFamily: "Inter",
    color: colors.black
  },
  notificationTime: {
    fontSize: moderateScale(11) / fontScalingFactor,
    fontWeight: "400",
    fontFamily: "Inter",
    color: colors.greyText,
    position: "absolute",
    top: "48%"
  }


})