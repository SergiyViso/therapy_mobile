import { FlatList, Image, SafeAreaView, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native'
import React, { useState } from 'react'
import { commonStyles, errorToast, fontScalingFactor, successToast, windowWidth } from '../../components/CommonStyles'
import MainHeader from '../../components/MainHeader'
import { moderateScale, scale } from 'react-native-size-matters'
import { colors } from '../../components/Colors'
import { images } from '../../components/Images'
import CommonButtons from '../../components/CommonButtons'
import { previousWeakRatingList, dummyData } from '../../utils/utils'
import { useDispatch, useSelector } from 'react-redux'
import { addingSymptoms, getSymptomToTrack, getUserSymptoms, PostSymptomsDetail } from '../../../redux/actions/mainAction'
import * as RNLocalize from "react-native-localize";
import AntDesign from 'react-native-vector-icons/AntDesign'
import Entypo from 'react-native-vector-icons/Entypo'
import { useEffect } from 'react'
import LoadingComponent from '../../components/LoadingComponent'
import moment from 'moment'
const Symptomtracking = () => {
    const token = useSelector(state => state.auth.accessToken)
    const symptomList = useSelector(state => state.main.userSymptomList)
    const [ratingToSend, setRatingToSend] = useState("9")
    const [text, setText] = useState("")
    const [timeZone, setTimeZone] = useState("")
    const [selecting, setSelecting] = useState(false)
    const [loader, setLoader] = useState(false);
    const [arrToSend, setArrToSend] = useState([])
    const [symptomNewArr, setSymptomNewArr] = useState(symptomList)
    const [filteredArr, setFilteredArr] = useState([])
    const [newLowerRating, setNewLowerRatting] = useState(previousWeakRatingList);
    const [rating, setRating] = useState(previousWeakRatingList);
    const dispatch = useDispatch()
    // console.log(JSON.stringify(symptomNewArr));

    useEffect(()=>{
        let timeZone = RNLocalize.getTimeZone()
        setTimeZone(timeZone)
    },[])

    const handleRatting = (item, index, dotIndex) => {
        let ratingArr = newLowerRating
        ratingArr.map((itemm, indexx) => {
            indexx == dotIndex ? itemm.isSelected = true : itemm.isSelected = false
            return { ...itemm }
        })
        setNewLowerRatting(ratingArr)
        // console.log(ratingArr[dotIndex], "ghkjhjhkhkhkjhk");

        let arr = [...symptomNewArr]
        arr.map((el, ind) => {
            index == ind ? (el.data = ratingArr) : (el.data = rating)
            return { ...el }
        })
        // console.log(JSON.stringify(arr), "llkkjlkjlljkllklkklkkljlklkj");

        setSymptomNewArr(arr)
        console.log(arr[index].title, "title");
        let title = arr[index].title
        let ratingg = arr[index].data[dotIndex].num
        console.log(arr[index].data[dotIndex].num, "ratingg");
        arrToSend.push({ title: title, rating: ratingg, id: arr[index].id })
        removeDuplicates()

    }
    // console.log(arrToSend);

    function removeDuplicates() {
        let books = arrToSend
        console.log(books);
        let newArray = [];
        let uniqueObject = {};
        for (let i in books) {
            let objTitle = books[i]['title'];
            uniqueObject[objTitle] = books[i];
        }
        for (let i in uniqueObject) {
            newArray.push(uniqueObject[i]);
        }
        console.log(newArray, "unique arrrrayyyyyyy");
        setArrToSend(newArray)
    }




    const addSymptom = () => {
        dispatch(addingSymptoms(text, token)).then(async res => {
            console.log(res, "adding Symptom");
            if (res.success == true) {
                successToast(res.message)
                setText("")
                await dispatch(getUserSymptoms(token))
            }
        }).catch((e) => {
            console.log(e, "error while adding Symptom");
        })
    }

    const addSymptomByRating = () => {
        if (arrToSend.length == 0) {
            errorToast("Please select atleast one Symptom! ")
        }
        else {
            var formdata = new FormData()
            formdata.append("rating", ratingToSend),
            formdata.append("timezone", timeZone),
                arrToSend.forEach(element => {
                    formdata.append(`symptom_ids[${element.id}]`, element.rating)
                });

            setLoader(true)
            dispatch(PostSymptomsDetail(token, formdata)).then(async res => {
                console.log(res, "response of posting symptom tracking!!!!!!!");
                if (res.success == true) {
                    successToast(res.message)
                    await dispatch(getSymptomToTrack(token))
                    setArrToSend([])
                    // resetMultipleSelect()
                }
                setLoader(false)
            }).catch(e => {
                console.log(e, "error of posting symptom tracking!!!!!!!");
                setLoader(false)
            })
        }
    }
    // console.log(token);
    useEffect(() => {

        resetMultipleSelect()

    }, [])

    const resetMultipleSelect = () => {
        if (symptomList.length > 0) {
            let newArr = [...symptomList]
            newArr.map((item, ind) => {
                // item.data=[...newLowerRating]
                item.isSelected = false
                return { ...item }
            })
            // console.log(JSON.stringify(newArr),"jsagdgjasfgsgfgfksjdfssfsfasfasf");
            setSymptomNewArr(newArr)
        }
    }
    const handleMultipleSelect = (index) => {
        let newArr = [...symptomList]
        newArr.map((item, ind) => {
            index == ind ? item.isSelected = !item.isSelected : item.isSelected = false
            index == ind ? item.data = [...newLowerRating] : null
            return { ...item }
        })
        setSymptomNewArr(newArr)

    }
    const handleRemoveSymptom = (item, index) => {
        //    alert(index)
        let arr = [...arrToSend]
        arr.splice(index, 1);
        // console.log(arr,"newwwww arrrrrrrr");
        setArrToSend(arr)
    }
    const renderArrayToTrack = ({ item, index }) => {
        return (
            <View style={styles.symptomsBox}>
                <Text style={styles.symptomText}>{item.title}  ( {item.rating} )</Text>
                <TouchableOpacity onPress={() => handleRemoveSymptom(item, index)} 
                style={{ position: "absolute", right: 5, top: 5 }}>
                    <Image
                        source={images.cross}
                        style={{ height: scale(18), width: scale(18) }}
                    />
                </TouchableOpacity>
            </View>
        )
    }


    return (
        <SafeAreaView style={commonStyles.mainContainer}>
            <MainHeader backIcon />
            {loader && <LoadingComponent />}
            <ScrollView>

                <View style={styles.topBox}>
                    <Text style={styles.topText}>Add or delete multiple
                        Fields according to
                        your Goals</Text>
                    <Image
                        source={images.goalsScreenImage}
                        style={styles.topImage}
                        resizeMode='stretch'
                    />
                </View>
                <Text style={styles.addText}>Add</Text>
                <TextInput
                    value={text}
                    onChangeText={(t) => setText(t)}
                    placeholder=''
                    style={styles.input}
                />
                <CommonButtons
                    onPress={() => addSymptom()}
                    title={"Add"} customStyle={styles.btnStyle} />
                <View style={styles.greyLine}></View>
                {
                    symptomList.length != 0 &&
                    <>
                        <View style={styles.bottomBox}>
                            <Text style={styles.dropDownTitle}>Select symptom</Text>
                            <TouchableOpacity activeOpacity={0.2} style={styles.customDrawerBox}
                                onPress={() => setSelecting(!selecting)}
                            >
                                <Text>general anxiety</Text>
                                <AntDesign name='down' color={colors.black} size={18} />
                            </TouchableOpacity>
                            <View style={{ marginTop: scale(10) }}>
                                {
                                    selecting &&
                                    symptomNewArr.map((item, index) => {
                                        return (<View style={{ flexDirection: 'column' }}>
                                            <TouchableOpacity style={styles.innerContent}
                                                onPress={() => handleMultipleSelect(index)}>
                                                <Text style={{
                                                    paddingHorizontal: scale(3),
                                                    // marginTop: scale(10),
                                                    marginHorizontal: scale(10)
                                                }}>
                                                    {item.title}
                                                </Text>
                                                {
                                                    item.isSelected ?
                                                        <AntDesign name="checkcircleo" size={scale(16)}
                                                            color={colors.black} />
                                                        :
                                                        <Entypo name='circle' size={scale(16)}
                                                            color={colors.black} />
                                                }
                                            </TouchableOpacity>

                                            {
                                                item.isSelected &&
                                                <View style={styles.ratingBox}>
                                                    <View style={styles.ratingLine}></View>
                                                    {
                                                        item.data.map((el, ind) => {
                                                            return (
                                                                <TouchableOpacity onPress={() => handleRatting(item, index, ind)}
                                                                    style={styles.ratingData}>
                                                                    <Image
                                                                        source={item.data[ind].isSelected ? images.selectedRating :
                                                                            images.ratingCircle}
                                                                        style={{ height: scale(15), width: scale(15) }}
                                                                        resizeMode='stretch'
                                                                    />
                                                                    <Text>{item.num}</Text>
                                                                </TouchableOpacity>
                                                            )
                                                        })
                                                    }
                                                </View>
                                            }
                                        </View>
                                        )
                                    })
                                }
                            </View>
                            {/* <View style={{flexDirection:"row",flexWrap:"wrap"}}> */}
                            {
                                arrToSend.length > 0 &&
                                <>
                                    <Text style={styles.arrHeading}>Added symptoms to track</Text>
                                    <FlatList
                                        data={arrToSend}
                                        keyExtractor={item => item.title}
                                        numColumns={2}
                                        renderItem={renderArrayToTrack}
                                    />
                                </>
                            }
                            {/* </View> */}
                            <CommonButtons
                                onPress={() => addSymptomByRating()}
                                title={"Save"} customStyle={styles.btnStyle2} />
                            <View style={{ height: 50 }}></View>
                        </View>
                    </>
                }
            </ScrollView>
        </SafeAreaView>
    )
}

export default Symptomtracking

const styles = StyleSheet.create({
    topBox: {
        height: scale(200),
        width: windowWidth - scale(30),
        alignSelf: "center",
        marginTop: scale(20),
        padding: scale(10)
    },
    topText: {
        fontSize: moderateScale(18) / fontScalingFactor,
        fontWeight: "700",
        fontFamily: "Plus Jakarta Sans",
        width: "50%",
        zIndex: 56,
        color: colors.signUpBtn,
        top: scale(20)
    },
    topImage: {
        position: "absolute",
        right: scale(10),
        top: scale(10),
        height: "100%",
        width: "60%"
    },
    addText: {
        alignSelf: "center",
        fontSize: moderateScale(16) / fontScalingFactor,
        fontWeight: "700",
        fontFamily: "Plus Jakarta Sans",
        color: colors.black,
        marginBottom: scale(8)
    },
    input: {
        height: scale(35),
        borderRadius: scale(10),
        borderWidth: 0.8, borderColor: colors.greyText,
        width: windowWidth - scale(50),
        alignSelf: "center",
        padding: scale(10)
    },
    btnStyle: {
        backgroundColor: colors.signUpBtn,
        width: windowWidth - scale(50),
        alignSelf: "center", marginTop: scale(10),
        height: scale(35)
    },
    btnStyle2: {
        backgroundColor: colors.buttonColor,
        width: windowWidth - scale(50),
        alignSelf: "center", marginTop: scale(10),
        height: scale(35)
    },

    greyLine: {
        height: 1,
        width: windowWidth,
        backgroundColor: colors.greyText,
        alignSelf: "center",
        marginVertical: scale(40)
    },
    ratingText: {
        alignSelf: "flex-end",
        right: scale(50),
        top: scale(-25),
        fontSize: moderateScale(14) / fontScalingFactor,
        fontWeight: "700",
        color: colors.black,
        fontFamily: "Inter"
    },
    dropDownTitle: {
        fontSize: moderateScale(16) / fontScalingFactor,
        fontWeight: "600",
        fontFamily: "Inter",
        marginVertical: scale(12),
        color: colors.black
    },
    bottomBox: {
        width: windowWidth - scale(50),
        alignSelf: "center"
    },
    ratingData: { height: "100%", width: "9%", marginRight: "1%", alignItems: "center", justifyContent: "center" },
    ratingBox: { height: scale(40), width: "100%", backgroundColor: "white", flexDirection: "row" },
    customDrawerBox: {
        height: scale(35),
        width: windowWidth - scale(30),
        borderWidth: 0.7,
        borderColor: colors.greyText,
        borderRadius: scale(8),
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        paddingHorizontal: scale(10),
        left: scale(-10),

    },
    selectionBox: {
        height: scale(200),
        width: windowWidth - 50,
        backgroundColor: "#f1f1f1",
        marginTop: scale(5),
    },
    innerContent: {
        flexDirection: "row",
        alignItems: "center",
        backgroundColor: colors.mainColor,
        paddingHorizontal: scale(3),
        borderRadius: scale(10),
        // flexWrap: "wrap",
        height: 30,
        margin: scale(4),
    },
    ratingLine: {
        height: 1, width: "90%", backgroundColor: "lightgrey",
        position: "absolute", zIndex: -2,
        top: scale(10) / fontScalingFactor, left: "5%"
    },
    symptomsBox: {
        minHeight: scale(35),
        width: windowWidth / 2.5,
        backgroundColor: colors.greyText,
        margin: scale(3),
        alignItems: "center",
        justifyContent: "center",
        borderRadius: scale(10)
    },
    symptomText: {
        color: colors.mainColor,
        fontSize: moderateScale(12) / fontScalingFactor
    },
    arrHeading: {
        alignSelf: "center", fontSize: moderateScale(18) / fontScalingFactor,
        color: colors.black, marginVertical: scale(5),
        fontWeight: "600"
    }


})