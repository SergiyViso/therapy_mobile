import { FlatList, Image, SafeAreaView, StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import React, { useEffect, useState } from 'react'
import MainHeader from '../../components/MainHeader'
import { commonStyles, fontScalingFactor, windowHeight, windowWidth } from '../../components/CommonStyles'
import { moderateScale, scale } from 'react-native-size-matters'
import { colors } from '../../components/Colors'
import { useDispatch, useSelector } from 'react-redux'
import { images } from '../../components/Images'
import moment from 'moment'
import CommonButtons from '../../components/CommonButtons'
import { useIsFocused } from '@react-navigation/native'
import LoadingComponent from '../../components/LoadingComponent'

const MyHomeWorks = (props) => {
    const homeWorkData = useSelector(state => state.main.homeWorkList)
    const [sortedList,setSortedList] = useState(homeWorkData)
    const [loader, setLoader] = useState(false)
    const IsFocused = useIsFocused()
    const emptyArr = {}

    useEffect(() => {
        sortingFunction()
    }, [sortedList,IsFocused])

   const  sortingFunction = ()=>{
        if (homeWorkData.length != 0) {
            const sorted = homeWorkData.sort((a, b) => {
                const dateA = new Date(`${a.created_at}`).valueOf();
                const dateB = new Date(`${b.created_at}`).valueOf();
                if (dateB > dateA) {
                    return 1; // return -1 here for DESC order
                }
                return -1 // return 1 here for DESC Order
            });
            setSortedList(sorted)
        }
   }
   
    const renderItem = ({ item, ind }) => {
        return (
            <TouchableOpacity activeOpacity={1} style={styles.newNotes2}
            onPress={()=>handleNavigation("Update",item)}
            >
                <Text numberOfLines={2} style={styles.date}>{item.short_description}</Text>
                <Text numberOfLines={2} style={styles.notes}>{item.description}</Text>
                <View style={styles.itemTimeBox}>
                    <Text style={styles.time}>{moment(item.created_at).format("hh:mm a")}</Text>
                    <Image
                        style={styles.redRightArrow}
                        source={images.redRightArrow}
                    />
                </View>
            </TouchableOpacity>
        )
    }

    const handleNavigation = (type, item) => {
        if (type == "New") {
            props.navigation.navigate("AddHomeWork", {
                data: {
                    short_description: "",
                    description: "",
                    thoughts: "",
                    file: "",
                    id:0
                },
                type:type
            })
        } else {
            props.navigation.navigate("AddHomeWork", {
                data: item
            })
        }
    }
    
    const renderEmptyArr = ()=>{
        return(
            <Text style={styles.date}>You don't have any Home-Work!!!</Text>
        )
    }
    return (
        <SafeAreaView style={commonStyles.mainContainer}>
            <MainHeader backIcon />
            {
                loader && <LoadingComponent />
            }
            <Text style={styles.screenTitle}>Home Work</Text>
            <CommonButtons title={"Add new"} customStyle={styles.btnStyle}
                onPress={() => handleNavigation("New", emptyArr)} />
            <View style={styles.notesBox2}>
                <FlatList
                    data={sortedList}
                    keyExtractor={item => item.id}
                    numColumns={2}
                    renderItem={renderItem}
                    ListEmptyComponent={renderEmptyArr}
                    showsVerticalScrollIndicator={false}
                />
            </View>
        </SafeAreaView>
    )
}

export default MyHomeWorks

const styles = StyleSheet.create({
    screenTitle: {
        fontSize: moderateScale(25) / fontScalingFactor,
        alignSelf: "center",
        fontWeight: "700",
        color: colors.signUpBtn, marginVertical: scale(10)
    },
    newNotes2: {
        height: scale(100),
        width: windowWidth / 2.5,
        borderRadius: 2,
        borderWidth: 0.1,
        justifyContent: "center",
        marginHorizontal: "1.5%",
        marginVertical: "2%",
        padding: 6,
        backgroundColor: "#f9f9f9"

    },
    notesBox: {
        maxHeight: windowHeight - scale(190),
    },
    notesBox2: {
        width: windowWidth - scale(20),
        paddingHorizontal: scale(15),
        marginTop: scale(15), flexDirection: "row",
        flexWrap: "wrap",
        alignItems: "center",
        alignSelf: "center",
        height:windowHeight/1.35
    },
    date: {
        fontSize: moderateScale(14) / fontScalingFactor,
        color: colors.signUpBtn,
        fontWeight: "500"
    },
    time: {
        fontSize: moderateScale(11) / fontScalingFactor,
        color: colors.time,
        fontWeight: "400"
    },
    notes: {
        fontSize: moderateScale(10) / fontScalingFactor,
        color: colors.notes,
        fontWeight: "400",
        paddingVertical: scale(6)
    },
    itemTimeBox: {
        flexDirection: "row",
        // justifyContent: "space-between"
    },
    redRightArrow: {
        height: scale(15),
        width: scale(15),
        left:scale(10)
    },
    btnStyle: {
        alignSelf: "flex-end",
        marginHorizontal: scale(10),
        height: scale(35)
    }

})