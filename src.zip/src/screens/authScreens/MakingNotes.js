import { FlatList, Image, SafeAreaView, StyleSheet, Text, View } from 'react-native'
import React, { useState } from 'react'
import { commonStyles, fontScalingFactor, windowHeight, windowWidth } from '../../components/CommonStyles'
import StatusBarComponent from '../../components/StatusBarComponent'
import { colors } from '../../components/Colors'
import { images } from '../../components/Images'
import { moderateScale, scale, verticalScale } from 'react-native-size-matters'
import CommonButtons from '../../components/CommonButtons'
import { slides } from '../../utils/utils';
import { useDispatch } from 'react-redux'
import { isAccessToken } from '../../../redux/actions/authAction'

const MakingNotes = (props) => {
    const [currentIndex, setcurrentIndex] = useState(0)
    const dispatch = useDispatch()
    // console.log(slides);
    const renderItem = ({ item }) => {
        return (
            <View style={{width:windowWidth}}>
                <Image
                    source={item.image}
                    style={styles.notesImage}
                    resizeMode="contain"
                />
                <Text style={styles.title}>{item.title}</Text>
                <Text style={styles.description}>{item.text}</Text>
            </View>
        );
    }
    const handlePress = ()=>{
        dispatch(isAccessToken("yes"))
    }
    return (
        <SafeAreaView style={commonStyles.mainContainer}>
            <StatusBarComponent />
            <View style={styles.contentBox}>
                <FlatList 
                    pagingEnabled 
                    horizontal={true} 
                    renderItem={renderItem} 
                    data={slides}
                    keyExtractor={(item=>item.id)}
                    onScroll={(e)=> {
                      let number =  e.nativeEvent.contentOffset.x/windowWidth
                        setcurrentIndex(Math.ceil(number))}}
                    showsHorizontalScrollIndicator={false}
                />
            </View>
            <View style={styles.dotContaienr}>
                {slides.map((item, index) => (
                    <View style={index ==currentIndex? styles.cricle:styles.cricle1} />
                ))}
            </View>
            <CommonButtons title={"Next"} customStyle={styles.btnStyle} />
            <CommonButtons title={"Skip"} customStyle={styles.btnStyle2} customText={styles.btnText} 
            onPress={()=>handlePress()}
            />
        </SafeAreaView>
    )
}

export default MakingNotes

const styles = StyleSheet.create({
    notesImage: {
        height: "70%",
        width: "100%",
        maxWidth:scale(260),
        alignSelf:"center",
        // marginTop:scale(60)
    },
    dotContaienr: {
        flexDirection: "row",
        alignSelf: "center"
    },
    cricle: {
        width: 10,
        height: 10,
        borderRadius: 10, marginHorizontal: 5,
        backgroundColor: "red",
    },
    cricle1: {
        width: 10,
        height: 10,
        borderRadius: 10, marginHorizontal: 5,
        backgroundColor: "#eecc",
    },
    slide: {
        height: 200,
    },
    contentBox: {
        height: windowHeight / 2,
        // width: ,
        marginTop: scale(60),
        alignSelf: "center"
    },
    title: {
        color: colors.signUpBtn,
        fontSize: moderateScale(25)/fontScalingFactor,
        alignSelf: "center",
        fontWeight: "700",
        marginTop: scale(20)
    },
    description: {
        color: colors.black,
        fontSize: moderateScale(14)/fontScalingFactor,
        alignSelf: "center",
        fontWeight: "300",
        marginTop: scale(5),
        width: windowWidth - scale(90),
        textAlign: "center"
    },
    btnStyle: {
        backgroundColor: colors.signUpBtn,
        borderRadius: 25,
        width: windowWidth - scale(70),
        alignSelf: "center", marginTop: scale(20)
    },
    btnStyle2: {
        backgroundColor: colors.white,
        borderRadius: 25,
        width: windowWidth - scale(72),
        alignSelf: "center", marginTop: scale(20),
        borderWidth: 1,
        borderColor: colors.signUpBtn,
        height: scale(48)
    },
    btnText: {
        color: colors.signUpBtn
    }

})