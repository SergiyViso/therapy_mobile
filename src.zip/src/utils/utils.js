import { images } from '../components/Images';

export const slides = [
  {
    key: 1,
    title: 'Start Making Notes',
    text: 'Notes For Therapy was created to help maximize your therapy experience. Have you ever felt.',
    image: images.notesImage,
    //   backgroundColor: '#59b2ab',
  },
  {
    key: 2,
    title: 'Start Making Notes',
    text: 'Notes For Therapy was created to help maximize your therapy experience. Have you ever felt.',
    image: images.notesImage,
  },
  {
    key: 3,
    title: 'Start Making Notes',
    text: 'Notes For Therapy was created to help maximize your therapy experience. Have you ever felt.',
    image: images.notesImage,
  }
];
export const boxes = [
  {
    id: 0, title1: "Therapy", title2: "Notes"
  },
  // {
  //     id:1,title1:"Couple",title2:"Therapy"
  // },
  // {
  //     id:2,title1:"Group",title2:"Therapy/Other"
  // },
]
export const notesData = [
  {
    id: 0, date: "Mon-12-21", notes: "Lorem Ipsum is simply dummy text of the printing and...", time: "7:30 am ",
    image: images.redRightArrow
  },
  {
    id: 1, date: "Wed-11-22", notes: "Lorem Ipsum is simply dummy text of the printing and...", time: "7:30 am ",
    image: images.redRightArrow
  },
  {
    id: 2, date: "Wed-03-01", notes: "Lorem Ipsum is simply dummy text of the printing and...", time: "7:30 am ",
    image: images.redRightArrow
  },
  {
    id: 3, date: "Mon-02-12", notes: "Lorem Ipsum is simply dummy text of the printing and...", time: "7:30 am ",
    image: images.redRightArrow
  },
  {
    id: 4, date: "Wed-02-10", notes: "Lorem Ipsum is simply dummy text of the printing and...", time: "7:30 am ",
    image: images.redRightArrow
  },
]
export const notesDropdownList = [
  { label: 'Item 1', value: 'Note 1' },
  { label: 'Item 2', value: 'Note 2' },
  { label: 'Item 3', value: 'Note 3' },
  { label: 'Item 4', value: 'Note 4' },
  { label: 'Item 5', value: 'Note 5' },
  { label: 'Item 6', value: 'Note 6' },
  { label: 'Item 7', value: 'Note 7' },
  { label: 'Item 8', value: 'Note 8' },
];
export const ratingList = [
  { id: 0, num: 1, image: images.ratingCircle, isSelected: false },
  { id: 1, num: 2, image: images.ratingCircle, isSelected: false },
  { id: 2, num: 3, image: images.ratingCircle, isSelected: false },
  { id: 3, num: 4, image: images.ratingCircle, isSelected: false },
  { id: 4, num: 5, image: images.ratingCircle, isSelected: false },
  { id: 5, num: 6, image: images.ratingCircle, isSelected: false },
  { id: 6, num: 7, image: images.ratingCircle, isSelected: false },
  { id: 7, num: 8, image: images.ratingCircle, isSelected: false },
  { id: 8, num: 9, image: images.selectedRating, isSelected: true },
  { id: 9, num: 10, image: images.ratingCircle, isSelected: false },
]
export const previousWeakRatingList = [
  { id: 0, num: 1, isSelected: false },
  { id: 1, num: 2, isSelected: false },
  { id: 2, num: 3, isSelected: false },
  { id: 3, num: 4, isSelected: false },
  { id: 4, num: 5, isSelected: false },
  { id: 5, num: 6, isSelected: false },
  { id: 6, num: 7, isSelected: false },
  { id: 7, num: 8, isSelected: false },
  { id: 8, num: 9, isSelected: true },
  { id: 9, num: 10, isSelected: false },
]
export const titles = [
  { id: 0, title: "Therapy", isSelected: true },
  { id: 1, title: "Challenges", count: "12", isSelected: false },
]
export const dummyData = [
  { id: 0, title: "Therapy", isSelected: true },
  { id: 1, title: "Challenges", count: "12", isSelected: false },
  { id: 2, title: "Therapyqwe", isSelected: true },
  { id: 3, title: "Challq   q", count: "12", isSelected: false },
  { id: 4, title: "Therq  ee", isSelected: true },
  { id: 5, title: "Challengeeqee d qd", count: "12", isSelected: false },
]
export const notesQuestions = [
  { id: 0, title: "What I feel proud of this week!", isSelected: true },
  { id: 1, title: "Wins of the week ", count: "12", isSelected: false },
  { id: 2, title: "Challenges of the week ", isSelected: true },
  { id: 3, title: "Topics I want to talk about in therapy", count: "12", isSelected: false },
  { id: 4, title: "Write about your self care for the week ", isSelected: true },
  { id: 5, title: "General journal entry for the week ", count: "12", isSelected: false },
  { id: 6, title: "Growth or change I noticed over the week  ", count: "12", isSelected: false },
  { id: 7, title: "New things I tried this week  ", count: "12", isSelected: false },
  { id: 8, title: "Things to work on this week", count: "12", isSelected: false },


]
export const therapyList = [
  {
    id: 0, title: "Today Appointment @ 12:00", appointmentTime: "12:00", notificationAt: "1m ago.",
    description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit dolor sit amet, consectetur adipiscing elit.  "
  },
  {
    id: 1, title: "Today Appointment @ 12:00", appointmentTime: "12:00", notificationAt: "1m ago.",
    description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit dolor sit amet, consectetur adipiscing elit.  "
  },
  {
    id: 2, title: "Today Appointment @ 12:00", appointmentTime: "12:00", notificationAt: "1m ago.",
    description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit dolor sit amet, consectetur adipiscing elit.  "
  },
]